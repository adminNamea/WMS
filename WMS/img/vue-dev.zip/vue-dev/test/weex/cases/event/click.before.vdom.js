({
  type: 'div',
  event: ['click'],
  children: [{
    type: 'text',
    attr: {
      value: '42'
    }
  }]
})
